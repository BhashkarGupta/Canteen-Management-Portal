// Controller for menu items analytics
import { sequelize } from '../config/database.js';
import OrderItem from '../models/OrderItem.js';
import MenuItem from '../models/MenuItem.js';
import MenuItemIngredient from '../models/MenuItemIngredient.js';
import Ingredient from '../models/Ingredient.js';

// Get popular menu items based on order count
export const getPopularMenuItems = async (req, res) => {
  try {
    const popularItems = await OrderItem.findAll({
      attributes: [
        'MenuItemId',
        [sequelize.fn('COUNT', sequelize.col('MenuItemId')), 'orderCount']
      ],
      group: ['MenuItemId'],
      include: [{ model: MenuItem, attributes: ['name', 'price'] }],
      order: [[sequelize.fn('COUNT', sequelize.col('MenuItemId')), 'DESC']],
      limit: 10 // Limit to top 10 popular items
    });

    res.status(200).json(popularItems);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error });
  }
};

// Get total ingredient usage based on orders
export const getIngredientUsageReport = async (req, res) => {
  try {
    const ingredientUsage = await MenuItemIngredient.findAll({
      attributes: [
        'IngredientId',
        [sequelize.fn('SUM', sequelize.col('quantityUsed')), 'totalUsed']
      ],
      group: ['IngredientId'],
      include: [{
        model: Ingredient,
        as: 'Ingredients',  // Explicitly set the association alias
        attributes: ['name', 'unit']
      }]
    });

    res.status(200).json(ingredientUsage);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error });
    console.log(error);
  }
};
